insert into user (userid,password,username) values ('root','password','admin');
insert into user (userid,password,username) values ('anupriya','root@1','admin');
insert into user (userid,password,username) values ('vini','root@2','admin');
insert into user (userid,password,username) values ('shwetha','root@3','admin');
insert into user (userid,password,username) values ('niswarth','root@4','admin');
insert into user (userid,password,username) values ('vikas','root@5','admin');