package com.cognizant.utility;

import lombok.Data;

@Data
public class ClaimStatusUtilResult {
	private String policyId;
	private String memberId;

}
