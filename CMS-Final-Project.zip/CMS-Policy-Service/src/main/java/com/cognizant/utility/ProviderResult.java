package com.cognizant.utility;

import lombok.Data;

@Data
public class ProviderResult {
	private String provider_Name;
	private String location;

}
