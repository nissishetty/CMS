package com.cognizant.utility;

import lombok.Data;

@Data
public class Help {
	private String policyName;
	private long totalClaimedAmt;

}
