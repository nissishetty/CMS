package com.cognizant.utility;

import lombok.Data;

@Data
public class EligibilityClaimResponse2 {
	private String policyName;
	private long totalClaimedAmt; 

}
