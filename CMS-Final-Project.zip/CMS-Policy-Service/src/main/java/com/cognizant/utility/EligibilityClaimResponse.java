package com.cognizant.utility;

import lombok.Data;

@Data
public class EligibilityClaimResponse {
	private String policyId;
	private String memberId;

}
