package com.cognizant.model;

import lombok.Data;

@Data
public class EliglibleClaimAmount {
	
	private String policyId;
	private String memberId;
	private String policyName;
	private long totalClaimedAmt;

}
