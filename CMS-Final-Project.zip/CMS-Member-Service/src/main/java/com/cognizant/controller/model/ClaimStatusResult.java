package com.cognizant.controller.model;

import lombok.Data;

@Data
public class ClaimStatusResult {
	private String claimStatus;
	private String claimDesc;

}
